
import React from 'react';
import { Home, Heart, Calendar, TrendingUp, Settings, List, History } from 'lucide-react';

interface SidebarProps {
  activePage: string;
  onNavigate: (page: any) => void;
}

const Logo = () => (
  <svg width="32" height="32" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" className="drop-shadow-lg">
    <circle cx="50" cy="45" r="35" fill="#3D7D4F" />
    <circle cx="50" cy="45" r="5" fill="white" />
    <circle cx="50" cy="23" r="8" fill="white" />
    <circle cx="71" cy="38" r="8" fill="white" />
    <circle cx="63" cy="62" r="8" fill="white" />
    <circle cx="37" cy="62" r="8" fill="white" />
    <circle cx="29" cy="38" r="8" fill="white" />
    <path 
      d="M40 75C40 75 55 85 80 85C95 85 100 80 100 80V74C100 74 90 80 80 80C60 80 40 72 40 72Z" 
      fill="#3D7D4F" 
    />
  </svg>
);

const Sidebar: React.FC<SidebarProps> = ({ activePage, onNavigate }) => {
  const menuItems = [
    { id: 'home', icon: Home, label: 'Home' },
    { id: 'favorites', icon: Heart, label: 'Favorites' },
    { id: 'mylist', icon: List, label: 'My List' },
    { id: 'history', icon: History, label: 'History' },
    { id: 'upcoming', icon: Calendar, label: 'Coming soon' },
    { id: 'trending', icon: TrendingUp, label: 'Trending' },
  ];

  const secondaryItems = [
    { id: 'settings', icon: Settings, label: 'Settings' },
  ];

  return (
    <aside className="fixed left-0 top-0 h-screen w-64 bg-[#0f1014] border-r border-white/5 p-6 flex flex-col gap-8 z-50 hidden lg:flex">
      <div className="flex items-center gap-3 px-2 cursor-pointer group" onClick={() => onNavigate('home')}>
        <div className="transition-transform duration-500 group-hover:rotate-12">
          <Logo />
        </div>
        <span className="text-2xl font-extrabold tracking-tight">J-cline</span>
      </div>

      <nav className="flex flex-col gap-2 overflow-y-auto no-scrollbar pr-2">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onNavigate(item.id)}
            className={`flex items-center gap-4 px-4 py-3 rounded-xl transition-all duration-200 group ${
              activePage === item.id ? 'bg-white/10 text-white shadow-xl shadow-black/20' : 'text-gray-500 hover:text-white hover:bg-white/5'
            }`}
          >
            <item.icon size={20} className={activePage === item.id ? 'text-white' : 'text-gray-500 group-hover:text-white'} />
            <span className="font-semibold text-sm">{item.label}</span>
          </button>
        ))}
      </nav>

      <nav className="flex flex-col gap-2 mt-auto pb-4">
        <div className="h-px bg-white/5 mx-4 mb-6" />
        {secondaryItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onNavigate(item.id)}
            className={`flex items-center gap-4 px-4 py-3 rounded-xl transition-all duration-200 group ${
              activePage === item.id ? 'bg-white/10 text-white shadow-xl shadow-black/20' : 'text-gray-500 hover:text-white hover:bg-white/5'
            }`}
          >
            <item.icon size={20} className={activePage === item.id ? 'text-white' : 'text-gray-500 group-hover:text-white'} />
            <span className="font-semibold text-sm">{item.label}</span>
          </button>
        ))}
      </nav>
    </aside>
  );
};

export default Sidebar;
