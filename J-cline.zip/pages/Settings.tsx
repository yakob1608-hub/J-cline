
import React, { useState, useEffect } from 'react';
import { 
  Settings, Shield, Bell, Monitor, Globe, User, LogOut, Film, 
  Tv, LogIn, Palette, Captions, Trash2, Eye, Zap, Database 
} from 'lucide-react';

const SettingsPage: React.FC = () => {
  // --- Account State ---
  const [userName, setUserName] = useState(() => localStorage.getItem('jc_name') || 'Yuki R.');
  const [userEmail, setUserEmail] = useState(() => localStorage.getItem('jc_email') || 'yuki.r@jcline.io');

  // --- Notification State ---
  const [movieNotif, setMovieNotif] = useState(() => JSON.parse(localStorage.getItem('jc_notif_movie') ?? 'true'));
  const [episodeNotif, setEpisodeNotif] = useState(() => JSON.parse(localStorage.getItem('jc_notif_episode') ?? 'true'));
  const [securityNotif, setSecurityNotif] = useState(() => JSON.parse(localStorage.getItem('jc_notif_security') ?? 'true'));

  // --- Streaming State ---
  const [quality, setQuality] = useState(() => localStorage.getItem('jc_stream_quality') || '4k');
  const [autoPlay, setAutoPlay] = useState(() => JSON.parse(localStorage.getItem('jc_autoplay') ?? 'true'));
  const [dataSaver, setDataSaver] = useState(() => JSON.parse(localStorage.getItem('jc_datasaver') ?? 'false'));

  // --- Appearance State ---
  const [theme, setTheme] = useState(() => localStorage.getItem('jc_theme') || 'emerald');
  const [language, setLanguage] = useState(() => localStorage.getItem('jc_lang') || 'en-US');

  // --- Subtitles State ---
  const [showSubs, setShowSubs] = useState(() => JSON.parse(localStorage.getItem('jc_subs_enabled') ?? 'true'));
  const [subStyle, setSubStyle] = useState(() => localStorage.getItem('jc_subs_style') || 'classic');

  // --- Privacy State ---
  const [personalization, setPersonalization] = useState(() => JSON.parse(localStorage.getItem('jc_privacy_personal') ?? 'true'));
  const [analytics, setAnalytics] = useState(() => JSON.parse(localStorage.getItem('jc_privacy_analytics') ?? 'false'));

  // Effect to persist changes and apply global theme
  useEffect(() => {
    localStorage.setItem('jc_name', userName);
    localStorage.setItem('jc_email', userEmail);
    localStorage.setItem('jc_notif_movie', JSON.stringify(movieNotif));
    localStorage.setItem('jc_notif_episode', JSON.stringify(episodeNotif));
    localStorage.setItem('jc_notif_security', JSON.stringify(securityNotif));
    localStorage.setItem('jc_stream_quality', quality);
    localStorage.setItem('jc_autoplay', JSON.stringify(autoPlay));
    localStorage.setItem('jc_datasaver', JSON.stringify(dataSaver));
    localStorage.setItem('jc_theme', theme);
    localStorage.setItem('jc_lang', language);
    localStorage.setItem('jc_subs_enabled', JSON.stringify(showSubs));
    localStorage.setItem('jc_subs_style', subStyle);
    localStorage.setItem('jc_privacy_personal', JSON.stringify(personalization));
    localStorage.setItem('jc_privacy_analytics', JSON.stringify(analytics));

    // Apply theme globally by updating CSS variables
    const colors: Record<string, string> = {
      emerald: '#10b981',
      sapphire: '#3b82f6',
      amethyst: '#a855f7',
      ruby: '#ef4444'
    };
    
    const color = colors[theme] || colors.emerald;
    document.documentElement.style.setProperty('--accent-color', color);
  }, [
    userName, userEmail, movieNotif, episodeNotif, securityNotif, 
    quality, autoPlay, dataSaver, theme, language, showSubs, 
    subStyle, personalization, analytics
  ]);

  const handleClearCache = () => {
    if (confirm('Are you sure? This will reset all your preferences and clear your watch list.')) {
      localStorage.clear();
      window.location.reload();
    }
  };

  const Toggle = ({ active, onToggle }: { active: boolean, onToggle: () => void }) => (
    <button 
      onClick={onToggle}
      className={`w-12 h-6 rounded-full transition-all relative ${active ? 'bg-emerald-600 shadow-lg shadow-emerald-600/30' : 'bg-white/10'}`}
    >
      <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${active ? 'right-1' : 'left-1'}`} />
    </button>
  );

  return (
    <div className="min-h-screen bg-[#0f1014] pt-8 px-6 pb-32">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-4 mb-10">
          <div className="w-12 h-12 bg-emerald-600/20 rounded-2xl flex items-center justify-center">
            <Settings className="text-emerald-500" size={24} />
          </div>
          <div>
            <h1 className="text-3xl font-black uppercase tracking-tight">System Settings</h1>
            <p className="text-sm text-gray-500 font-medium">Fine-tune your J-cline experience</p>
          </div>
        </div>

        <div className="flex flex-col gap-6">
          
          {/* 1. Account Profile */}
          <div className="bg-white/5 border border-white/5 rounded-[2rem] p-8 backdrop-blur-sm">
            <div className="flex flex-col md:flex-row items-center justify-between mb-8 gap-6">
               <div className="flex items-center gap-4">
                  <div className="w-20 h-20 rounded-3xl overflow-hidden border-2 border-emerald-600/20 relative group cursor-pointer">
                    <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Yuki" alt="Avatar" className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-black/60 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <p className="text-[10px] font-black uppercase">Change</p>
                    </div>
                  </div>
                  <div>
                    <input 
                      type="text" 
                      value={userName} 
                      onChange={(e) => setUserName(e.target.value)}
                      className="bg-transparent text-2xl font-black uppercase tracking-tight text-white outline-none border-b border-transparent focus:border-emerald-500 transition-colors w-full"
                    />
                  </div>
               </div>
               <div className="text-right">
                  <p className="text-[10px] text-gray-500 font-black uppercase mb-1">Account ID</p>
                  <p className="text-xs font-mono text-gray-400">JC-88291-XL</p>
               </div>
            </div>

            <div className="grid gap-4">
               <div className="flex flex-col gap-1.5 px-4 py-3 bg-black/20 rounded-2xl border border-white/5">
                  <span className="text-[9px] font-black text-gray-500 uppercase tracking-widest">Email Address</span>
                  <input 
                    type="email" 
                    value={userEmail}
                    onChange={(e) => setUserEmail(e.target.value)}
                    className="bg-transparent text-sm font-bold text-white outline-none"
                  />
               </div>
            </div>
          </div>

          {/* 2. Appearance & Themes */}
          <div className="bg-white/5 border border-white/5 rounded-[2rem] p-8 backdrop-blur-sm">
            <div className="flex items-center gap-3 mb-6">
              <Palette size={18} className="text-emerald-500" />
              <h3 className="text-xs font-black uppercase tracking-widest text-gray-500">Appearance</h3>
            </div>
            
            <div className="grid gap-4">
              <div className="flex items-center justify-between p-4 bg-black/20 rounded-2xl border border-white/5">
                <div>
                  <p className="text-sm font-bold text-white">Interface Theme</p>
                  <p className="text-[10px] text-gray-500 uppercase tracking-tight">Change accent color across the app</p>
                </div>
                <div className="flex gap-2">
                  {[
                    { id: 'emerald', color: 'bg-emerald-500' },
                    { id: 'sapphire', color: 'bg-blue-500' },
                    { id: 'amethyst', color: 'bg-purple-500' },
                    { id: 'ruby', color: 'bg-red-500' },
                  ].map((t) => (
                    <button 
                      key={t.id}
                      onClick={() => setTheme(t.id)}
                      className={`w-8 h-8 rounded-full ${t.color} border-2 transition-all transform hover:scale-110 ${theme === t.id ? 'border-white scale-110 shadow-lg' : 'border-transparent'}`}
                    />
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-between p-4 bg-black/20 rounded-2xl border border-white/5">
                <div className="flex items-center gap-4">
                  <Globe size={18} className="text-gray-400" />
                  <span className="text-sm font-bold text-white">Global Language</span>
                </div>
                <select 
                  value={language}
                  onChange={(e) => setLanguage(e.target.value)}
                  className="bg-transparent text-xs font-black uppercase tracking-widest outline-none cursor-pointer text-gray-400 hover:text-white transition-colors"
                >
                  <option value="en-US" className="bg-[#1a1b1e]">English (US)</option>
                  <option value="ja-JP" className="bg-[#1a1b1e]">Japanese</option>
                  <option value="es-ES" className="bg-[#1a1b1e]">Spanish</option>
                  <option value="fr-FR" className="bg-[#1a1b1e]">French</option>
                </select>
              </div>
            </div>
          </div>

          {/* 3. Streaming & Playback */}
          <div className="bg-white/5 border border-white/5 rounded-[2rem] p-8 backdrop-blur-sm">
            <div className="flex items-center gap-3 mb-6">
              <Zap size={18} className="text-emerald-500" />
              <h3 className="text-xs font-black uppercase tracking-widest text-gray-500">Streaming & Playback</h3>
            </div>
            
            <div className="grid gap-4">
              <div className="flex items-center justify-between p-4 bg-black/20 rounded-2xl border border-white/5">
                <div className="flex items-center gap-4">
                  <Monitor size={18} className="text-gray-400" />
                  <div>
                    <p className="text-sm font-bold text-white">Preferred Quality</p>
                    <p className="text-[10px] text-gray-500 uppercase">Will use high bandwidth</p>
                  </div>
                </div>
                <select 
                  value={quality}
                  onChange={(e) => setQuality(e.target.value)}
                  className="bg-transparent text-xs font-black uppercase tracking-widest outline-none cursor-pointer text-emerald-500"
                >
                  <option value="auto" className="bg-[#1a1b1e]">Auto Adaptive</option>
                  <option value="4k" className="bg-[#1a1b1e]">Ultra HD (4K)</option>
                  <option value="1080p" className="bg-[#1a1b1e]">Full HD (1080p)</option>
                  <option value="720p" className="bg-[#1a1b1e]">Standard (720p)</option>
                </select>
              </div>

              <div className="flex items-center justify-between p-4 bg-black/20 rounded-2xl border border-white/5">
                <div>
                  <p className="text-sm font-bold text-white">Auto-play Next Episode</p>
                  <p className="text-[10px] text-gray-500 uppercase tracking-tight">Seamlessly play next chapter</p>
                </div>
                <Toggle active={autoPlay} onToggle={() => setAutoPlay(!autoPlay)} />
              </div>

              <div className="flex items-center justify-between p-4 bg-black/20 rounded-2xl border border-white/5">
                <div>
                  <p className="text-sm font-bold text-white">Mobile Data Saver</p>
                  <p className="text-[10px] text-gray-500 uppercase tracking-tight">Limit bitrate to save data</p>
                </div>
                <Toggle active={dataSaver} onToggle={() => setDataSaver(!dataSaver)} />
              </div>
            </div>
          </div>

          {/* 4. Subtitles & Accessibility */}
          <div className="bg-white/5 border border-white/5 rounded-[2rem] p-8 backdrop-blur-sm">
            <div className="flex items-center gap-3 mb-6">
              <Captions size={18} className="text-emerald-500" />
              <h3 className="text-xs font-black uppercase tracking-widest text-gray-500">Subtitles</h3>
            </div>
            
            <div className="grid gap-4">
              <div className="flex items-center justify-between p-4 bg-black/20 rounded-2xl border border-white/5">
                <p className="text-sm font-bold text-white">Enable Subtitles by Default</p>
                <Toggle active={showSubs} onToggle={() => setShowSubs(!showSubs)} />
              </div>

              <div className="flex items-center justify-between p-4 bg-black/20 rounded-2xl border border-white/5">
                <div>
                  <p className="text-sm font-bold text-white">Subtitle Style</p>
                  <p className="text-[10px] text-gray-500 uppercase">Visual appearance of text</p>
                </div>
                <select 
                  value={subStyle}
                  onChange={(e) => setSubStyle(e.target.value)}
                  className="bg-transparent text-xs font-black uppercase tracking-widest outline-none cursor-pointer text-gray-400"
                >
                  <option value="classic" className="bg-[#1a1b1e]">Classic (White)</option>
                  <option value="contrast" className="bg-[#1a1b1e]">High Contrast (Yellow)</option>
                  <option value="minimal" className="bg-[#1a1b1e]">Minimalist Shadow</option>
                </select>
              </div>
            </div>
          </div>

          {/* 5. Notification Center */}
          <div className="bg-white/5 border border-white/5 rounded-[2rem] p-8 backdrop-blur-sm">
            <div className="flex items-center gap-3 mb-6">
              <Bell size={18} className="text-emerald-500" />
              <h3 className="text-xs font-black uppercase tracking-widest text-gray-500">Notifications</h3>
            </div>
            
            <div className="grid gap-4">
              <div className="flex items-center justify-between p-4 bg-black/20 rounded-2xl border border-white/5">
                <div className="flex items-center gap-4">
                  <div className="p-2.5 bg-amber-500/10 rounded-xl"><LogIn size={20} className="text-amber-500" /></div>
                  <p className="text-sm font-bold text-white">Security & Login Alerts</p>
                </div>
                <Toggle active={securityNotif} onToggle={() => setSecurityNotif(!securityNotif)} />
              </div>

              <div className="flex items-center justify-between p-4 bg-black/20 rounded-2xl border border-white/5">
                <div className="flex items-center gap-4">
                  <div className="p-2.5 bg-emerald-500/10 rounded-xl"><Film size={20} className="text-emerald-500" /></div>
                  <p className="text-sm font-bold text-white">New Movie Releases</p>
                </div>
                <Toggle active={movieNotif} onToggle={() => setMovieNotif(!movieNotif)} />
              </div>

              <div className="flex items-center justify-between p-4 bg-black/20 rounded-2xl border border-white/5">
                <div className="flex items-center gap-4">
                  <div className="p-2.5 bg-blue-500/10 rounded-xl"><Tv size={20} className="text-blue-500" /></div>
                  <p className="text-sm font-bold text-white">TV Series Updates</p>
                </div>
                <Toggle active={episodeNotif} onToggle={() => setEpisodeNotif(!episodeNotif)} />
              </div>
            </div>
          </div>

          {/* 6. Privacy & Security */}
          <div className="bg-white/5 border border-white/5 rounded-[2rem] p-8 backdrop-blur-sm">
            <div className="flex items-center gap-3 mb-6">
              <Shield size={18} className="text-emerald-500" />
              <h3 className="text-xs font-black uppercase tracking-widest text-gray-500">Privacy</h3>
            </div>
            
            <div className="grid gap-4">
              <div className="flex items-center justify-between p-4 bg-black/20 rounded-2xl border border-white/5">
                <div>
                  <p className="text-sm font-bold text-white">Content Personalization</p>
                  <p className="text-[10px] text-gray-500 uppercase">Allow recommendations based on history</p>
                </div>
                <Toggle active={personalization} onToggle={() => setPersonalization(!personalization)} />
              </div>

              <div className="flex items-center justify-between p-4 bg-black/20 rounded-2xl border border-white/5">
                <div>
                  <p className="text-sm font-bold text-white">Usage Analytics</p>
                  <p className="text-[10px] text-gray-500 uppercase">Send anonymous data to improve app</p>
                </div>
                <Toggle active={analytics} onToggle={() => setAnalytics(!analytics)} />
              </div>
            </div>
          </div>

          {/* 7. Data Management */}
          <div className="bg-white/5 border border-white/5 rounded-[2rem] p-8 backdrop-blur-sm">
            <div className="flex items-center gap-3 mb-6">
              <Database size={18} className="text-red-500" />
              <h3 className="text-xs font-black uppercase tracking-widest text-gray-500">Data Management</h3>
            </div>
            
            <div className="grid gap-4">
              <div className="flex flex-col md:flex-row items-center justify-between p-4 bg-red-500/5 rounded-2xl border border-red-500/10 gap-4">
                <div>
                  <p className="text-sm font-bold text-red-500">Clear Application Cache</p>
                  <p className="text-[10px] text-gray-500 uppercase">Wipes all locally stored data and reset preferences</p>
                </div>
                <button 
                  onClick={handleClearCache}
                  className="px-6 py-2 bg-red-500/10 text-red-500 border border-red-500/20 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-red-500 hover:text-white transition-all"
                >
                  Wipe Everything
                </button>
              </div>
            </div>
          </div>

          <button className="flex items-center justify-center gap-3 w-full p-5 bg-white/5 hover:bg-red-500/10 text-gray-400 hover:text-red-500 rounded-[2rem] border border-white/5 hover:border-red-500/20 transition-all font-black uppercase text-xs tracking-[0.2em]">
            <LogOut size={16} /> Sign Out of All Devices
          </button>

          <p className="text-center text-[9px] text-gray-700 font-bold uppercase tracking-[0.3em] mt-4">
            J-cline Client v4.2.0-stable • Build 8821
          </p>
        </div>
      </div>
    </div>
  );
};

export default SettingsPage;
