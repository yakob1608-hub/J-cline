
import React, { useState, useEffect } from 'react';
import { tmdb } from '../services/tmdb';
import { Movie } from '../types';
import MovieCard from '../components/MovieCard';
import { Calendar } from 'lucide-react';

interface UpcomingProps {
  onMovieSelect: (movie: Movie) => void;
  onToggleFavorite: (movie: Movie) => void;
  favorites: Movie[];
}

const Upcoming: React.FC<UpcomingProps> = ({ onMovieSelect, onToggleFavorite, favorites }) => {
  const [movies, setMovies] = useState<Movie[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchUpcoming = async () => {
      setLoading(true);
      try {
        const data = await tmdb.getUpcoming();
        
        // Filter for movies that are strictly NOT released yet
        const today = new Date().toISOString().split('T')[0];
        const strictlyUpcoming = data.filter(movie => {
          if (!movie.release_date) return false;
          return movie.release_date > today;
        });
        
        // Sort by release date (closest first)
        strictlyUpcoming.sort((a, b) => (a.release_date || '').localeCompare(b.release_date || ''));
        
        setMovies(strictlyUpcoming);
      } catch (error) {
        console.error("Error fetching upcoming movies:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchUpcoming();
  }, []);

  return (
    <div className="min-h-screen bg-[#0f1014] pt-8 px-6 pb-20">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center gap-4 mb-10">
          <div className="w-12 h-12 bg-amber-500/10 rounded-2xl flex items-center justify-center">
            <Calendar className="text-amber-500" size={24} />
          </div>
          <div>
            <h1 className="text-3xl font-black uppercase tracking-tight">Strictly Upcoming</h1>
            <p className="text-sm text-gray-500 font-medium">Unreleased titles arriving soon to J-cline</p>
          </div>
        </div>

        {loading ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-6">
            {Array.from({ length: 12 }).map((_, i) => (
              <div key={i} className="aspect-[2/3] bg-white/5 rounded-3xl animate-pulse border border-white/5" />
            ))}
          </div>
        ) : movies.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-x-6 gap-y-10 animate-in fade-in slide-in-from-bottom-4 duration-500">
            {movies.map((movie) => (
              <MovieCard 
                key={movie.id} 
                movie={movie} 
                onClick={onMovieSelect}
                onFavoriteToggle={onToggleFavorite}
                isFavorited={favorites.some(f => f.id === movie.id)}
              />
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-32 text-center bg-white/5 rounded-3xl border border-dashed border-white/10">
            <Calendar size={48} className="text-gray-700 mb-4" />
            <h2 className="text-xl font-bold text-gray-400">No unreleased titles found</h2>
            <p className="text-sm text-gray-600 max-w-xs mt-2">
              Check back later for new announcements and upcoming blockbuster releases.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Upcoming;
