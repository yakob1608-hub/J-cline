
import React, { useState, useEffect, useCallback } from 'react';
import Navbar from './components/Navbar';
import Sidebar from './components/Sidebar';
import BottomNav from './components/BottomNav';
import Home from './pages/Home';
import Details from './pages/Details';
import Search from './pages/Search';
import Browse from './pages/Browse';
import Favorites from './pages/Favorites';
import MyList from './pages/MyList';
import History from './pages/History';
import Upcoming from './pages/Upcoming';
import Trending from './pages/Trending';
import SettingsPage from './pages/Settings';
import { Movie } from './types';

export interface NotificationItem {
  id: string;
  type: 'security' | 'movie' | 'episode' | 'system';
  title: string;
  message: string;
  time: string;
  isRead: boolean;
  timestamp: number;
}

const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<string>('home');
  const [selectedMovie, setSelectedMovie] = useState<Movie | null>(null);
  const [isUpcomingSelection, setIsUpcomingSelection] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  
  // Storage hooks
  const [favorites, setFavorites] = useState<Movie[]>(() => {
    const saved = localStorage.getItem('jcline-favorites');
    return saved ? JSON.parse(saved) : [];
  });

  const [myList, setMyList] = useState<Movie[]>(() => {
    const saved = localStorage.getItem('jcline-mylist');
    return saved ? JSON.parse(saved) : [];
  });

  const [watchHistory, setWatchHistory] = useState<Movie[]>(() => {
    const saved = localStorage.getItem('jcline-history');
    return saved ? JSON.parse(saved) : [];
  });

  const [notifications, setNotifications] = useState<NotificationItem[]>(() => {
    const saved = localStorage.getItem('jcline-notifications');
    return saved ? JSON.parse(saved) : [
      {
        id: '1',
        type: 'movie',
        title: 'Welcome to J-cline',
        message: 'Start exploring our premium 4K library today.',
        time: 'Just now',
        isRead: false,
        timestamp: Date.now()
      }
    ];
  });

  useEffect(() => {
    localStorage.setItem('jcline-favorites', JSON.stringify(favorites));
  }, [favorites]);

  useEffect(() => {
    localStorage.setItem('jcline-mylist', JSON.stringify(myList));
  }, [myList]);

  useEffect(() => {
    localStorage.setItem('jcline-history', JSON.stringify(watchHistory));
  }, [watchHistory]);

  useEffect(() => {
    localStorage.setItem('jcline-notifications', JSON.stringify(notifications));
  }, [notifications]);

  const addNotification = useCallback((type: NotificationItem['type'], title: string, message: string) => {
    const newNotif: NotificationItem = {
      id: Math.random().toString(36).substr(2, 9),
      type,
      title,
      message,
      time: 'Just now',
      isRead: false,
      timestamp: Date.now()
    };
    setNotifications(prev => [newNotif, ...prev]);
  }, []);

  const markAsRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, isRead: true } : n));
  };

  const markAllRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
  };

  const removeNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const clearAllNotifications = () => {
    setNotifications([]);
  };

  const toggleFavorite = (movie: Movie) => {
    setFavorites(prev => {
      const isFavorited = prev.some(f => f.id === movie.id);
      if (isFavorited) {
        addNotification('system', 'Removed from Library', `"${movie.title || movie.name}" removed.`);
        return prev.filter(f => f.id !== movie.id);
      } else {
        addNotification('system', 'Added to Library', `"${movie.title || movie.name}" is now in your favorites.`);
        return [...prev, movie];
      }
    });
  };

  const toggleMyList = (movie: Movie) => {
    setMyList(prev => {
      const isInList = prev.some(m => m.id === movie.id);
      if (isInList) {
        addNotification('system', 'Watchlist Updated', `"${movie.title || movie.name}" removed from your list.`);
        return prev.filter(m => m.id !== movie.id);
      } else {
        addNotification('system', 'Watchlist Updated', `"${movie.title || movie.name}" added to your list.`);
        return [...prev, movie];
      }
    });
  };

  const clearHistory = () => {
    setWatchHistory([]);
    addNotification('system', 'History Cleared', 'Your watch history has been wiped.');
  };

  const handleMovieSelect = (movie: Movie, isUpcoming: boolean = false) => {
    setSelectedMovie(movie);
    setIsUpcomingSelection(isUpcoming);
    
    if (!isUpcoming) {
      setWatchHistory(prev => {
        const filtered = prev.filter(m => m.id !== movie.id);
        return [movie, ...filtered].slice(0, 50);
      });
    }
  };

  const handleNavigate = (page: string) => {
    if (page === 'explore_menu') {
      setCurrentPage(prev => prev === 'movies' ? 'tv' : 'movies');
    } else {
      setCurrentPage(page);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="flex min-h-screen bg-[#0f1014] text-white overflow-x-hidden pb-24 lg:pb-0">
      <Sidebar activePage={currentPage} onNavigate={handleNavigate} />
      
      <div className="flex-1 flex flex-col min-w-0">
        <Navbar 
          onSearch={setSearchQuery} 
          onNavigate={handleNavigate} 
          notifications={notifications}
          onMarkRead={markAsRead}
          onMarkAllRead={markAllRead}
          onRemove={removeNotification}
          onClearAll={clearAllNotifications}
        />
        
        <main className="flex-1 transition-all ml-0 lg:ml-64 py-4">
          {currentPage === 'home' && (
            <Home 
              onMovieSelect={(m) => handleMovieSelect(m, false)} 
              onToggleFavorite={toggleFavorite}
              onToggleMyList={toggleMyList}
              favorites={favorites}
              myList={myList}
              onNavigate={handleNavigate}
            />
          )}
          
          {currentPage === 'movies' && (
            <Browse 
              type="movie" 
              onMovieSelect={(m) => handleMovieSelect(m, false)} 
              onToggleFavorite={toggleFavorite}
              favorites={favorites}
            />
          )}

          {currentPage === 'tv' && (
            <Browse 
              type="tv" 
              onMovieSelect={(m) => handleMovieSelect(m, false)} 
              onToggleFavorite={toggleFavorite}
              favorites={favorites}
            />
          )}

          {currentPage === 'search' && (
            <Search 
              query={searchQuery} 
              onMovieSelect={(m) => handleMovieSelect(m, false)} 
              onToggleFavorite={toggleFavorite}
              favorites={favorites}
            />
          )}

          {currentPage === 'favorites' && (
            <Favorites 
              movies={favorites} 
              onMovieSelect={(m) => handleMovieSelect(m, false)}
              onToggleFavorite={toggleFavorite}
            />
          )}

          {currentPage === 'mylist' && (
            <MyList 
              movies={myList} 
              onMovieSelect={(m) => handleMovieSelect(m, false)}
              onToggleMyList={toggleMyList}
            />
          )}

          {currentPage === 'history' && (
            <History 
              movies={watchHistory} 
              onMovieSelect={(m) => handleMovieSelect(m, false)}
              onClearHistory={clearHistory}
            />
          )}

          {currentPage === 'upcoming' && (
            <Upcoming 
              onMovieSelect={(m) => handleMovieSelect(m, true)}
              onToggleFavorite={toggleFavorite}
              favorites={favorites}
            />
          )}

          {currentPage === 'trending' && (
            <Trending 
              onMovieSelect={(m) => handleMovieSelect(m, false)}
              onToggleFavorite={toggleFavorite}
              favorites={favorites}
            />
          )}

          {currentPage === 'settings' && (
            <SettingsPage />
          )}
        </main>

        <footer className="ml-0 lg:ml-64 py-12 px-6 border-t border-white/5 bg-black/20 text-center md:text-left mb-20 lg:mb-0">
          <div className="flex flex-col md:flex-row justify-between items-center gap-6">
            <div>
              <span className="text-sm font-bold text-gray-500 uppercase tracking-widest leading-none">Powered by J-cline Engine</span>
              <p className="text-xs text-gray-600 mt-2 leading-none">© 2024 J-cline Streaming. All metadata from TMDB.</p>
            </div>
            <div className="flex gap-6">
              <span className="text-xs text-gray-500 cursor-pointer hover:text-white transition-colors">Privacy</span>
              <span className="text-xs text-gray-500 cursor-pointer hover:text-white transition-colors" onClick={() => handleNavigate('settings')}>Settings</span>
            </div>
          </div>
        </footer>
      </div>

      {/* Details Overlay - Restored to Overlay Mode */}
      {selectedMovie && (
        <Details 
          movie={selectedMovie} 
          isUpcoming={isUpcomingSelection}
          onClose={() => setSelectedMovie(null)} 
          onToggleFavorite={toggleFavorite}
          onToggleMyList={toggleMyList}
          isFavorited={favorites.some(f => f.id === selectedMovie.id)}
          isInMyList={myList.some(m => m.id === selectedMovie.id)}
        />
      )}

      <BottomNav activePage={currentPage} onNavigate={handleNavigate} />
    </div>
  );
};

export default App;
