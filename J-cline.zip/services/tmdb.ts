
import { Movie, MovieDetails, Genre, Season, Episode } from '../types';

const API_KEY = '2a39231cb3fd088b64c312689f9a9844';
const BASE_URL = 'https://api.themoviedb.org/3';

export const getImageUrl = (path: string, size: string = 'w500') => {
  if (!path) return 'https://picsum.photos/500/750?grayscale';
  return `https://image.tmdb.org/t/p/${size}${path}`;
};

export const tmdb = {
  getTrending: async (type: 'all' | 'movie' | 'tv' = 'all'): Promise<Movie[]> => {
    const res = await fetch(`${BASE_URL}/trending/${type}/day?api_key=${API_KEY}`);
    const data = await res.json();
    return data.results;
  },

  getPopular: async (type: 'movie' | 'tv'): Promise<Movie[]> => {
    const res = await fetch(`${BASE_URL}/${type}/popular?api_key=${API_KEY}`);
    const data = await res.json();
    return data.results.map((item: any) => ({ ...item, media_type: type }));
  },

  getTopRated: async (type: 'movie' | 'tv'): Promise<Movie[]> => {
    const res = await fetch(`${BASE_URL}/${type}/top_rated?api_key=${API_KEY}`);
    const data = await res.json();
    return data.results.map((item: any) => ({ ...item, media_type: type }));
  },

  getUpcoming: async (): Promise<Movie[]> => {
    const res = await fetch(`${BASE_URL}/movie/upcoming?api_key=${API_KEY}`);
    const data = await res.json();
    return data.results.map((item: any) => ({ ...item, media_type: 'movie' }));
  },

  getDetails: async (type: 'movie' | 'tv', id: number): Promise<MovieDetails> => {
    const res = await fetch(`${BASE_URL}/${type}/${id}?api_key=${API_KEY}`);
    const data = await res.json();
    return { ...data, media_type: type };
  },

  getSeasonDetails: async (id: number, seasonNumber: number): Promise<{ episodes: Episode[] }> => {
    const res = await fetch(`${BASE_URL}/tv/${id}/season/${seasonNumber}?api_key=${API_KEY}`);
    return await res.json();
  },

  search: async (query: string): Promise<Movie[]> => {
    const res = await fetch(`${BASE_URL}/search/multi?api_key=${API_KEY}&query=${encodeURIComponent(query)}`);
    const data = await res.json();
    return data.results.filter((item: any) => item.media_type === 'movie' || item.media_type === 'tv');
  },

  getGenres: async (type: 'movie' | 'tv'): Promise<Genre[]> => {
    const res = await fetch(`${BASE_URL}/genre/${type}/list?api_key=${API_KEY}`);
    const data = await res.json();
    return data.genres;
  },

  getDiscover: async (type: 'movie' | 'tv', genreId?: number): Promise<Movie[]> => {
    const genreParam = genreId ? `&with_genres=${genreId}` : '';
    const res = await fetch(`${BASE_URL}/discover/${type}?api_key=${API_KEY}${genreParam}`);
    const data = await res.json();
    return data.results.map((item: any) => ({ ...item, media_type: type }));
  }
};
